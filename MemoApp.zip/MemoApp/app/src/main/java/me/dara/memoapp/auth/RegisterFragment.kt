package me.dara.memoapp.auth


import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import kotlinx.android.synthetic.main.fragment_register.*
import me.dara.memoapp.Alert
import me.dara.memoapp.LoadingDialog
import me.dara.memoapp.R
import me.dara.memoapp.network.model.Status


class RegisterFragment : Fragment() {

  lateinit var listener: OnLoginClickListener
  val loading: LoadingDialog by lazy {
    LoadingDialog().apply {
      isCancelable = false
    }
  }

  lateinit var viewModel: AuthViewModel


  override fun onAttach(context: Context) {
    super.onAttach(context)
    listener = context as OnLoginClickListener
  }

  override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                            savedInstanceState: Bundle?): View? {
    return inflater.inflate(R.layout.fragment_register, container, false)

  }

  override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
    viewModel = ViewModelProviders.of(activity!!).get(AuthViewModel::class.java)
    imgCloseRegister.setOnClickListener {
      listener.onCloseClicked()
    }

    btnRegister.setOnClickListener {
      if (validateInput()) {
        signUp(editRegisterEmail.text?.toString()!!, editConfirmPassword.text?.toString()!!)
      }
    }

    editConfirmPassword.addTextChangedListener(object : FormTextWatcher() {
      override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (s?.length!! > 0) {
          inputRegisterConfirmPassword.error = ""
        }
      }
    })

    editRegisterEmail.addTextChangedListener(object : FormTextWatcher() {
      override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (s?.length!! > 0) {
          inputRegisterEmail.error = ""
        }
      }
    })
    editRegisterPassword.addTextChangedListener(object : FormTextWatcher() {
      override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (s?.length!! > 0) {
          inputRegisterPassword.error = ""
        }
      }
    })

  }

  fun signUp(email: String, password: String) {
    loading.show(childFragmentManager, "ProgressLoading")
//    viewModel.signUp(email, password).observe(viewLifecycleOwner, Observer { response ->
//      loading.dismiss()
//      if (response.status == Status.SUCCESS) {
//        Alert().apply {
//          msg = getString(R.string.email_sent, email)
//          title = getString(R.string.info)
//          positiveFun = {
//            listener.registerSuccess()
//          }
//          show(childFragmentManager, "Alert")
//        }
//      } else {
//        Toast.makeText(context, R.string.registration_error, Toast.LENGTH_SHORT).show()
//      }
//    })
  }

  private fun validateInput(): Boolean {
    val email = editRegisterEmail.text?.toString()!!
    val password = editRegisterPassword.text?.toString()!!
    val confirm = editConfirmPassword.text?.toString()!!
    var isValid = true
    if (email.isEmpty()) {
      inputRegisterEmail.error = requireContext().resources.getString(R.string.fill_username)
      isValid = false
    }
    if (password.isEmpty()) {
      inputRegisterPassword.error = requireContext().resources.getString(R.string.fill_password)
      isValid = false
    }
    if (confirm.isEmpty()) {
      inputRegisterConfirmPassword.error = requireContext().resources.getString(R.string.fill_password)
      isValid = false
    }

    return isValid
  }


}


package me.dara.memoapp

import android.app.Dialog
import android.content.res.ColorStateList
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatDialogFragment
import android.view.View

/**
 * @author sardor
 */
class Alert : AppCompatDialogFragment() {

  var title: String = ""
  var msg = ""

  var positiveFun: (view: View) -> Unit = {}

  override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

    val dialog = AlertDialog.Builder(requireContext()).setTitle(title)
        .setMessage(msg)
        .setPositiveButton(android.R.string.yes) { dialog, _ ->
          positiveFun
          dialog.dismiss()
        }
        .create()
    dialog.setOnShowListener {
      dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(
          ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.colorPrimary)))
      dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(
          ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.colorPrimary)))
    }
    return dialog
  }
}
package me.dara.memoapp

import me.dara.memoapp.network.MemoService

/**
 * @author sardor
 */
class AppModule(val webService: MemoService) {



}